# LaunchPad v1.0.2
### Cole Schwochow's personal career command center

**Live site:** https://chowchow2918.github.io/launchpad/

## What's in this folder
- `index.html` — the full app (single file, ~400KB)
- `version.json` — version manifest, checked automatically by the app for updates
- `README.md` — this file

## Publishing an update
1. Make your edits to `index.html` (or get an updated version)
2. Bump the `"version"` number in `version.json` (e.g. `1.0.2` → `1.0.3`)
3. Update the `"notes"` and `"changelog"` fields to describe what changed
4. Go to your GitHub repo → drag both files in via **Add file → Upload files**
5. Commit changes
6. Anyone with the app open will see an "Update available" banner within
   seconds — clicking it reloads to the new version automatically

## How the auto-update system works
The app checks `https://chowchow2918.github.io/launchpad/version.json`
about 3 seconds after loading. If the version number there is newer than
the version baked into `index.html`, a banner slides up from the bottom
with an "Update now" button. No build step, no app store — just replace
the file on GitHub and everyone gets notified.

## API features (CareerHelpAI, resume tailor, job import, salary scripts)
These require the app to be accessed over a real URL (not opened as a
local file) since they call the Anthropic API directly from the browser.
The GitHub Pages URL above satisfies this — once live there, all AI
features work normally.

## Adzuna live job listings (optional)
1. Create a free account at developer.adzuna.com
2. Get your App ID and App Key from the dashboard
3. In LaunchPad, go to Settings → paste both keys → Save
4. Use the "Test connection" button to confirm it's working
5. Go to Find Jobs and click to load live listings

## Local testing (without GitHub)
If you want to test changes locally before pushing:
```bash
# Python
python3 -m http.server 8080
# then open localhost:8080 in your browser

# Node
npx serve .
```
Opening `index.html` directly as a file (double-click) will work for
browsing and most features, but AI-powered features will be disabled —
the app will show a banner explaining this.

---
Built with LaunchPad · v1.0.2 · github.com/chowchow2918/launchpad
